/* global QUnit */

sap.ui.require(["sync/e05/homework1/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
