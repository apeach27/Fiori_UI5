sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("sync.e05.homework1.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  